package miage.upo.feuillepresence.models;

import java.util.List;

public class Promotion{

    public long id;
    public String anneeScolaire;
    public String groupe;
    public String type;
    public List<Etudiant> sesEtudiants;
    public String filiere;
    public List<Matiere> sesMatieres;

    public Promotion() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAnneeScolaire() {
        return anneeScolaire;
    }

    public void setAnneeScolaire(String anneeScolaire) {
        this.anneeScolaire = anneeScolaire;
    }

    public String getGroupe() {
        return groupe;
    }

    public void setGroupe(String groupe) {
        this.groupe = groupe;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<Etudiant> getSesEtudiants() {
        return sesEtudiants;
    }

    public void setSesEtudiants(List<Etudiant> sesEtudiants) {
        this.sesEtudiants = sesEtudiants;
    }

    public String getFiliere() {
        return filiere;
    }

    public void setFiliere(String filiere) {
        this.filiere = filiere;
    }

    public List<Matiere> getSesMatieres() {
        return sesMatieres;
    }

    public void setSesMatieres(List<Matiere> sesMatieres) {
        this.sesMatieres = sesMatieres;
    }
}

