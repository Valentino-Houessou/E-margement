package miage.upo.feuillepresence.models;

import java.util.List;

public class Enseignant{

    public int id;
    public String statut;
    public Utilisateur sonUtilisateur;
    public List<Matiere> sesMatieres;

    public Enseignant() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Utilisateur getSonUtilisateur() {
        return sonUtilisateur;
    }

    public void setSonUtilisateur(Utilisateur sonUtilisateur) {
        this.sonUtilisateur = sonUtilisateur;
    }

    public List<Matiere> getSesMatieres() {
        return sesMatieres;
    }

    public void setSesMatieres(List<Matiere> sesMatieres) {
        this.sesMatieres = sesMatieres;
    }
}
