package miage.upo.feuillepresence.helpers;

import android.util.Log;
import android.app.Dialog;
import android.os.AsyncTask;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.io.IOException;
import java.io.InputStream;
import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.io.BufferedInputStream;
import java.net.MalformedURLException;
import java.util.List;

import miage.upo.feuillepresence.models.Error;
import miage.upo.feuillepresence.app.AppConfig;


/**
 * Created by BabyBryan on 16/04/2016.
 */
public class DataLoadManager extends AsyncTask<Void, Void, Object> {

    private String TAG_LPT;
    private Dialog pDialog;
    private AppConfig.ObjectFromUrl url;
    private HashMap<String,String> send_item;
    private DataLoadInterface iListener;

    public DataLoadManager(AppConfig.ObjectFromUrl url, Dialog pDialog, HashMap<String, String> send_item, DataLoadInterface mListener) {
        this.url = url;
        this.pDialog = pDialog;
        this.send_item = send_item;
        this.iListener = mListener;
    }

    @Override
    protected void onPreExecute() {
        /* Creation Log */
        TAG_LPT = this.getClass().getCanonicalName();
        Log.i(TAG_LPT, "DataLoadManager - onPreExecute message");
        showDialog();
        super.onPreExecute();
    }

    @Override
    protected Object doInBackground(Void... params) {
        Log.i(TAG_LPT, "DataLoadManager - doInBackground message");
        try {
            /* Objet retourné */
            Object jsonToObject = null;
            /* Creation Mapper */
            ObjectMapper mapper = new ObjectMapper();;
            /* Formation de L'URL */
            URL url_link = new URL(url.getUrl());
            /* Connexion à l'URL */
            HttpURLConnection urlConnection = (HttpURLConnection) url_link.openConnection();
            /* Configuration de la connexion */
            setProperties(urlConnection);
            /* Etablissement de la connexion */
            urlConnection.connect();
            /* Envoie des données */
            writeRequest(urlConnection,mapper,send_item);
            /* Lecture de la réponse */
            jsonToObject = ReadResponse(urlConnection, mapper, jsonToObject);
            /* Déconnexion */
            urlConnection.disconnect();
            /* Return  */
            return jsonToObject;
        } catch (MalformedURLException e) {
            Log.e(TAG_LPT, "Mauvaise URL !", e);
        } catch (IOException e) {
            Log.e(TAG_LPT, "Connexion Impossible", e);
        }
        return null;
    }

    private void setProperties(HttpURLConnection urlConnection) throws ProtocolException {
        Log.i(TAG_LPT, "DataLoadManager - setProperties message");
        /* Passe la connexion en POST */
        urlConnection.setRequestMethod("POST");
        /* Parametre gestion Json */
        urlConnection.setRequestProperty("Content-Type", "application/json");
        urlConnection.setRequestProperty("Accept", "application/json");
        /* Active envoie et reception de data */
        urlConnection.setDoInput(true);
        urlConnection.setDoOutput(true);
    }

    private void writeRequest(HttpURLConnection urlConnection,ObjectMapper mapper,HashMap map) {
        Log.i(TAG_LPT, "DataLoadManager - writeRequest message");
        try{
            /* Envoie de la requete */
            DataOutputStream dataOutputStream = new DataOutputStream(urlConnection.getOutputStream());
            dataOutputStream.writeBytes(mapper.writeValueAsString(map));
            dataOutputStream.flush();
            dataOutputStream.close();
        }catch (Exception e ){
            Log.e(TAG_LPT, "Problème lors de l'envoie des données", e);
        }
    }

    private Object ReadResponse(HttpURLConnection urlConnection, ObjectMapper mapper, Object jsonToObject) {
        Log.i(TAG_LPT, "DataLoadManager - ReadResponse message");
        try{
            if(urlConnection.getResponseMessage().equals("Bad Request")){
                jsonToObject = readBadRequest(urlConnection, mapper, jsonToObject);

            }else if (urlConnection.getResponseMessage().equals("OK")){
                jsonToObject = readSuccessRequest(urlConnection, mapper, jsonToObject);

            }
        }catch (Exception e ){
            Log.e(TAG_LPT, "Problème lors de la reception des données", e);
        }
        return jsonToObject;
    }

    private Object readSuccessRequest(HttpURLConnection urlConnection, ObjectMapper mapper,Object jsonToObject) throws IOException {
        Log.i(TAG_LPT, "DataLoadManager - readSuccessRequest message");
        /* Lire la reponse de l'URL */
        InputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
        /* Conversion du Json en Objet */
        jsonToObject = mapper.readValue(inputStream, url.getReturnObject());
        Log.i(TAG_LPT, jsonToObject.toString());
        /* Fermeture du flux d'info */
        inputStream.close();
        if(jsonToObject instanceof Object[]){
            List<Object> coursList = new ArrayList<>();
            for (int i=0;i<((Object[])jsonToObject).length;i++) {
                coursList.add(((Object []) jsonToObject)[i]);
            }
            jsonToObject = coursList;
        }
        Log.i(TAG_LPT, jsonToObject.toString());
        return jsonToObject;
    }

    private Object readBadRequest(HttpURLConnection urlConnection, ObjectMapper mapper, Object jsonToObject) throws IOException {
        Log.i(TAG_LPT, "DataLoadManager - readBadRequest message");
        /* Lire la reponse de l'URL */
        InputStream inputStream = new BufferedInputStream(urlConnection.getErrorStream());
        /* Conversion du string en Json */
        jsonToObject = mapper.readValue(inputStream,Error.class);
        /* Fermeture du flux d'info */
        inputStream.close();
        return jsonToObject;
    }

    @Override
    protected void onProgressUpdate(Void... values) {
        Log.i(TAG_LPT, "DataLoadManager - onProgressUpdate message");
    }

    @Override
    protected void onPostExecute(Object object) {
        Log.i(TAG_LPT, "DataLoadManager - onPostExecute message");
        iListener.dataLoadReturn(object);
        hideDialog();
    }

    /* Affichage du dialog */
    private void showDialog() {
        Log.i(TAG_LPT, "DataLoadManager - showDialog message");
        if (!pDialog.isShowing())
            pDialog.show();
    }

    /* Cachage du dialog */
    private void hideDialog() {
        Log.i(TAG_LPT, "DataLoadManager - hideDialog message");
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
}
