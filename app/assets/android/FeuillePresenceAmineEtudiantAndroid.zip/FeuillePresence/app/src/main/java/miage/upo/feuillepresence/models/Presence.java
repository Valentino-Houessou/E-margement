package miage.upo.feuillepresence.models;

public class Presence{

    public int id;
    public boolean emergement;
    public String motif;
    public String justificatif;
    public Cours sonCours;
    public Etudiant sonEtudiant;

    public Presence(){
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isEmergement() {
        return emergement;
    }

    public void setEmergement(boolean emergement) {
        this.emergement = emergement;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public String getJustificatif() {
        return justificatif;
    }

    public void setJustificatif(String justificatif) {
        this.justificatif = justificatif;
    }

    public Cours getSonCours() {
        return sonCours;
    }

    public void setSonCours(Cours sonCours) {
        this.sonCours = sonCours;
    }

    public Etudiant getSonEtudiant() {
        return sonEtudiant;
    }

    public void setSonEtudiant(Etudiant sonEtudiant) {
        this.sonEtudiant = sonEtudiant;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Presence presence = (Presence) o;

        if (id != presence.id) return false;
        if (!sonCours.equals(presence.sonCours)) return false;
        return sonEtudiant.equals(presence.sonEtudiant);

    }

    @Override
    public int hashCode() {
        int result = id;
        result = 31 * result + sonCours.hashCode();
        result = 31 * result + sonEtudiant.hashCode();
        return result;
    }
}
