package miage.upo.feuillepresence.controllers;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import miage.upo.feuillepresence.R;
import miage.upo.feuillepresence.app.AppConfig;
import miage.upo.feuillepresence.helpers.ComplexeListAdapter;
import miage.upo.feuillepresence.helpers.DataLoadInterface;
import miage.upo.feuillepresence.helpers.DataLoadManager;
import miage.upo.feuillepresence.helpers.SessionManager;
import miage.upo.feuillepresence.models.Error;
import miage.upo.feuillepresence.models.Presence;

/**
 * Created by BabyBryan on 26/04/2016.
 */
public class PresenceActivity extends Activity {

    private String TAG_LOG;
    private SessionManager session;
    private HashMap<String,String> send_item;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        /* Creation Log */
        TAG_LOG = this.getClass().getCanonicalName();
        Log.i(TAG_LOG, "PresenceActivity - onCreate message");
        /* Instanciation Activité */
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_presence);

        /* Instanciation de la session --> session_start() php */
        session = new SessionManager(getApplicationContext());
        /* Verification de la connexion */
        session.checkLogin();

        /* Recupération de l'intent */
        Intent intent = getIntent();

        /* Récupération de l'id */
        String cours_id = intent.getStringExtra("EXTRA_PARAM_COURS_ID");
        String cours_title = intent.getStringExtra("EXTRA_PARAM_COURS_TITLE");

        /* Configuration du progressDialog */
        /* Creation du progressDialog */
        final ProgressDialog progressDialog = new ProgressDialog(PresenceActivity.this);
        progressDialog.setMessage(getText(R.string.presence_activity_progress_message_presence));
        progressDialog.setCancelable(false);

        /* Configuration du HashMap */
        send_item = new HashMap<>();
        send_item.put("cours",cours_id);

        /* Chargement du tire */
        TextView title_textView = (TextView) findViewById(R.id.presence_activity_textView_title);
        title_textView.setText(cours_title);

        /* Trouver la listView */
        final ListView listView = (ListView) findViewById(R.id.presence_activity_listView_presence);
        listView.setAdapter(null);

        Button button = (Button) findViewById(R.id.presence_activity_button_signature);

        /* chargement de la liste + récupération des absents */
        final List<Presence> absent = loadPresence(progressDialog, listView);

        /* action sur clic */
        onSignatureClic(button);
        updatePresence(listView, absent);
        onBackClic();
    }

    private void onSignatureClic(Button button) {
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* On signe */
                ProgressDialog p = new ProgressDialog(PresenceActivity.this);
                p.setCancelable(false);
                p.setMessage(getText(R.string.presence_activity_progress_message_signature));
                DataLoadManager dataLoadManager = new DataLoadManager(AppConfig.URL_SET_SINGATURE,p, send_item, new DataLoadInterface() {
                    @Override
                    public void dataLoadReturn(Object object) {
                        /* On affiche un toast */
                        if(object instanceof Error){
                            Error error = (Error) object;
                            Toast.makeText(getApplicationContext(),
                                    error.getError(), Toast.LENGTH_LONG)
                                    .show();
                        }
                        if(object instanceof String){
                            alreadySign((String) object);
                        }
                    }
                });
                dataLoadManager.execute();
            }
        });
    }

    private void alreadySign(String object) {
        /* Creation de alertdialog */
        AlertDialog alertDialog = new AlertDialog.Builder(PresenceActivity.this).create();
                            /* Application du titre */
        alertDialog.setTitle(getText(R.string.presence_activity_dialog_title).toString());
                            /* Application du message */
        alertDialog.setMessage(object);
                            /* Application d'un bouton OK */
        alertDialog.setButton(DialogInterface.BUTTON_NEUTRAL,"OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                /* On sort de la page */
                onBackPressed();
            }
        });
        /* Affichage de l'alert */
        alertDialog.show();
    }

    private void updatePresence(ListView listView, final List<Presence> absent) {
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                /* Récupération de l'item */
                Presence presence = (Presence) parent.getItemAtPosition(position);
                /* Change l'émargement */
                presence.setEmergement(!presence.isEmergement());
                /* Envoie des données */
                send_item.put("cours",String.valueOf(presence.getSonCours().getId()));
                send_item.put("idEtu",String.valueOf(presence.getSonEtudiant().getId()));
                send_item.put("presence",String.valueOf(presence.isEmergement()));
                String message = getText(R.string.presence_activity_dialog_message_1) +
                        presence.getSonEtudiant().getSonUtilisateur().getNom() + " " +
                        presence.getSonEtudiant().getSonUtilisateur().getPrenom() + " ";
                message += presence.isEmergement() ? getText(R.string.presence_activity_dialog_message_2a) : getText(R.string.presence_activity_dialog_message_2b);
                final ProgressDialog progressDialogClic = new ProgressDialog(PresenceActivity.this);
                progressDialogClic.setMessage(message);
                progressDialogClic.setCancelable(false);
                DataLoadManager dataLoadManager = new DataLoadManager(
                        AppConfig.URL_SET_PRESENT,
                        progressDialogClic,
                        send_item,
                        new DataLoadInterface() {
                            @Override
                            public void dataLoadReturn(Object object) {
                                if(object instanceof Error){
                                    Error error = (Error) object;
                                    Toast.makeText(getApplicationContext(),
                                            error.getError(), Toast.LENGTH_LONG)
                                            .show();
                                }
                                if(object instanceof String){
                                    Toast.makeText(getApplicationContext(),
                                            object.toString(), Toast.LENGTH_LONG)
                                            .show();
                                }
                            }
                        }
                );
                dataLoadManager.execute();
                /* Mis à jour de la vue */
                /* Retire ou ajoute l'objet de la liste absence */
                /* Change la vue */
                ImageView status = (ImageView) view.findViewById(R.id.presence_list_imageView_status);
                if(presence.isEmergement()){
                    absent.remove(presence);
                    status.setImageResource(R.color.presence_list_emargement_true);
                }else{
                    absent.add(presence);
                    status.setImageResource(R.color.presence_list_emargement_false);
                }
                /* Mise à jour nombre d'absence */
                TextView textView = (TextView) findViewById(R.id.presence_activity_textView_absent);
                textView.setText(getText(R.string.presence_activity_textView_absent_1) + " " + absent.size() + " " +
                        getText(R.string.presence_activity_textView_absent_2) + " " + presence.getSonCours().getSaPromo().getSesEtudiants().size() + " " +
                        getText(R.string.presence_activity_textView_absent_3));

                return false;
            }
        });
    }

    private List<Presence> loadPresence(ProgressDialog progressDialog, final ListView listView) {
        final List<Presence> absent = new ArrayList<>();
        /* Chargement des presences */
        DataLoadManager dataLoadManager = new DataLoadManager(AppConfig.URL_GET_PRESENCE, progressDialog, send_item, new DataLoadInterface() {
            @Override
            public void dataLoadReturn(Object object) {
                if(object != null){
                    if(object instanceof List){
                        /* Creation de la liste */
                        /* Element de la liste */
                        List<Object> presenceList = (List<Object>) object;
                        /* Creation de l'adapter qui liera les données à la vue */
                        ComplexeListAdapter complexeListAdapter = new ComplexeListAdapter(PresenceActivity.this, R.layout.list_presence,presenceList);
                        /* Association de l'adaptateurau layout (ListView) */
                        listView.setAdapter(complexeListAdapter);
                        /* Ajout dynamique de l'élément */
                        complexeListAdapter.notifyDataSetChanged();
                        /* Mise à jour nombre d'absence */
                        TextView textView = (TextView) findViewById(R.id.presence_activity_textView_absent);
                        for (Object p : presenceList ) {
                            if( p instanceof Presence)
                                if(!((Presence) p).emergement)
                                    absent.add((Presence) p);
                        }
                        textView.setText(getText(R.string.presence_activity_textView_absent_1) + " " + absent.size() + " " +
                                         getText(R.string.presence_activity_textView_absent_2) + " " + presenceList.size() + " " +
                                         getText(R.string.presence_activity_textView_absent_3));
                    }
                    if(object instanceof Error){
                        Error error = (Error) object;
                        alreadySign(error.getError());
                    }
                }else {
                    Toast.makeText(getApplicationContext(),
                            R.string.global_toast_error, Toast.LENGTH_LONG)
                            .show();
                }
            }
        });
        dataLoadManager.execute();
        return absent;
    }

    private void onBackClic() {
        /* Clic sur Back */
        Button back_button = (Button) findViewById(R.id.presence_activity_button_back);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public static void startActivity(Context context){
        Log.i("TAG_LOG","PresenceActivity - startActivity message");
        Intent intent = new Intent(context, PresenceActivity.class);
        context.startActivity(intent);
    }

    public static Intent newActivityIntent(Context context, String cours_id, String cours_title){
        Log.i("TAG_LOG", "PresenceActivity - newActivityIntent message");
        Intent intent = new Intent(context, PresenceActivity.class);
        intent.putExtra("EXTRA_PARAM_COURS_ID", cours_id);
        intent.putExtra("EXTRA_PARAM_COURS_TITLE", cours_title);
        return intent;
    }

    @Override
    protected void onStop() {
        Log.i("TAG_LOG", "PresenceActivity - onStop message");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.i("TAG_LOG", "PresenceActivity - onDestroy message");
        super.onDestroy();
    }
}
