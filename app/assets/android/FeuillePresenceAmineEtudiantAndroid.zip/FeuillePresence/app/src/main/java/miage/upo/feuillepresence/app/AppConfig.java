package miage.upo.feuillepresence.app;

import miage.upo.feuillepresence.models.Cours;
import miage.upo.feuillepresence.models.Presence;
import miage.upo.feuillepresence.models.Utilisateur;

/**
 * Created by BabyBryan on 15/04/2016.
 */
public class AppConfig {
    /* Type of device */
    static final String LOCALHOST = "127.0.0.1";
    static final String ANDROID_STUDIO = "10.0.2.2";
    static final String ANDROID_VM = "10.0.2.15";
    static final String GENYMOTION = "192.168.56.1";
    static final String SERVEUR = "192.168.5.250";
    /* Liste d'URL d'action*/
    public static final ObjectFromUrl URL_LOGIN = new ObjectFromUrl("http://" + SERVEUR + ":9000/anLogin", Utilisateur.class);
    public static final ObjectFromUrl URL_GET_COURS_LIST = new ObjectFromUrl("http://" + SERVEUR + ":9000/enseignant/anlistCours", Cours[].class);
    public static final ObjectFromUrl URL_GET_PRESENCE = new ObjectFromUrl("http://" + SERVEUR + ":9000/enseignant/anlistPresence", Presence[].class);
    public static final ObjectFromUrl URL_SET_PRESENT = new ObjectFromUrl("http://" + SERVEUR + ":9000/enseignant/update", String.class);
    public static final ObjectFromUrl URL_SET_SINGATURE = new ObjectFromUrl("http://" + SERVEUR + ":9000/enseignant/anSignature", String.class);
    public static final ObjectFromUrl URL_GET_NBPRESENCE = new ObjectFromUrl("http://" + SERVEUR + ":9000/etudiant/anEtudiant", String.class);
    public static final ObjectFromUrl URL_GET_ABSENCE = new ObjectFromUrl("http://" + SERVEUR + ":9000/etudiant/anListAbsence", Presence[].class);

    public static class ObjectFromUrl {
        private String url;
        private Class returnObject;

        public ObjectFromUrl(String url, Class returnObject) {
            this.url = url;
            this.returnObject = returnObject;
        }

        public String getUrl() {
            return url;
        }

        public Class getReturnObject() {
            return returnObject;
        }

    }
}
