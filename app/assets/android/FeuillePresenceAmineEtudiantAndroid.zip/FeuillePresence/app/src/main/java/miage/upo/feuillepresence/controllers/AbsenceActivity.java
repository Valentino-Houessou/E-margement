package miage.upo.feuillepresence.controllers;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import miage.upo.feuillepresence.R;
import miage.upo.feuillepresence.app.AppConfig;
import miage.upo.feuillepresence.helpers.ComplexeListAdapter;
import miage.upo.feuillepresence.helpers.DataLoadInterface;
import miage.upo.feuillepresence.helpers.DataLoadManager;
import miage.upo.feuillepresence.helpers.SessionManager;
import miage.upo.feuillepresence.models.*;
import miage.upo.feuillepresence.models.Error;

/**
 * Created by amiikene on 12/05/2016.
 */
public class AbsenceActivity extends Activity {

    private String TAG_LOG;
    private SessionManager session;
    private HashMap<String,String> send_item;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        /* Creation Log */
        TAG_LOG = this.getClass().getCanonicalName();
        Log.i(TAG_LOG, "AbsenceActivity - onCreate message");
        /* Instanciation Activité */
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_absence);

        /* Instanciation de la session --> session_start() php */
        session = new SessionManager(getApplicationContext());
        /* Verification de la connexion */
        session.checkLogin();

        /* Configuration du progressDialog */
        /* Creation du progressDialog */
        final ProgressDialog progressDialog = new ProgressDialog(AbsenceActivity.this);
        progressDialog.setMessage(getText(R.string.liste_absence_activity_progress_message_listeabsence));
        progressDialog.setCancelable(false);

        String user_id = session.sessionData().get("user_id");

        /* Configuration du HashMap */
        send_item = new HashMap<>();
        send_item.put("user_id", user_id);

        /* Trouver la listView */
        final ListView listView = (ListView) findViewById(R.id.listAbsence_activity_listView);
        listView.setAdapter(null);

        /* récupération de la liste des absence */
        DataLoadManager dataLoadManager = new DataLoadManager(AppConfig.URL_GET_ABSENCE, progressDialog, send_item, new DataLoadInterface() {
            @Override
            public void dataLoadReturn(Object object) {
                if(object != null){
                    if(object instanceof List){
                        /* Creation de la liste */
                        /* Element de la liste */
                        List<Object> absenceList = (List<Object>) object;
                        /* Creation de l'adapter qui liera les données à la vue */
                        ComplexeListAdapter complexeListAdapter = new ComplexeListAdapter(AbsenceActivity.this, R.layout.list_absence, absenceList);
                        /* Association de l'adaptateurau layout (ListView) */
                        listView.setAdapter(complexeListAdapter);
                        /* Ajout dynamique de l'élément */
                        complexeListAdapter.notifyDataSetChanged();
                    }
                    if(object instanceof miage.upo.feuillepresence.models.Error){
                        Error error = (Error) object;
                        alreadySign(error.getError());
                    }
                }else {
                    Toast.makeText(getApplicationContext(),
                            R.string.global_toast_error, Toast.LENGTH_LONG)
                            .show();
                }
            }
        });
        dataLoadManager.execute();

        onBackClic();
    }

    private void alreadySign(String object) {
        /* Creation de alertdialog */
        AlertDialog alertDialog = new AlertDialog.Builder(AbsenceActivity.this).create();
                            /* Application du titre */
        alertDialog.setTitle(getText(R.string.presence_activity_dialog_title).toString());
                            /* Application du message */
        alertDialog.setMessage(object);
                            /* Application d'un bouton OK */
        alertDialog.setButton(DialogInterface.BUTTON_NEUTRAL,"OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                /* On sort de la page */
                onBackPressed();
            }
        });
        /* Affichage de l'alert */
        alertDialog.show();
    }

    private void onBackClic() {
        /* Clic sur Back */
        Button back_button = (Button) findViewById(R.id.listAbsence_activity_button_back);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    public static void startActivity(Context context){
        Log.i("TAG_LOG","AbsenceActivity - startActivity message");
        Intent intent = new Intent(context, AbsenceActivity.class);
        context.startActivity(intent);
    }

    public static Intent newActivityIntent(Context context){
        Log.i("TAG_LOG", "AbsenceActivity - newActivityIntent message");
        Intent intent = new Intent(context, AbsenceActivity.class);
        return intent;
    }

    @Override
    protected void onStop() {
        Log.i("TAG_LOG", "AbsenceActivity - onStop message");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.i("TAG_LOG", "AbsenceActivity - onDestroy message");
        super.onDestroy();
    }

}
