package miage.upo.feuillepresence.controllers;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;

import miage.upo.feuillepresence.R;
import miage.upo.feuillepresence.app.AppConfig;
import miage.upo.feuillepresence.helpers.DataLoadInterface;
import miage.upo.feuillepresence.helpers.DataLoadManager;
import miage.upo.feuillepresence.helpers.SessionManager;
import miage.upo.feuillepresence.models.*;
import miage.upo.feuillepresence.models.Error;

/**
 * Created by amiikene on 10/05/2016.
 */
public class EtudiantActivity extends Activity {
    private String TAG_LOG;
    private SessionManager session;
    private HashMap<String,String> params;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        /* Creation Log */
        TAG_LOG = this.getClass().getCanonicalName();
        Log.i(TAG_LOG, "EtudiantActivity - onCreate message");
        /* Instanciation Activité */
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_etudiant);

        /* Instanciation de la session --> session_start() php */
        session = new SessionManager(getApplicationContext());
        /* Verification de la connexion */
        session.checkLogin();

         /* Récupération de l'id */
        String user_id = session.sessionData().get("user_id");

        /* Configuration du progressDialog */
        /* Creation du progressDialog */
        final ProgressDialog progressDialog = new ProgressDialog(EtudiantActivity.this);
        progressDialog.setMessage(getText(R.string.etudiant_activity_progress_message_nbpresence));
        progressDialog.setCancelable(false);

         /* Instanciation Hashmap parametre à envoyer */
        params = new HashMap<String, String>();
        /* Passage des parametres */
        params.put("user_id", user_id);

        /* recupérer le text view pour lui indiquer le nbr d'absence */
        final TextView nbrAbsence_textView = (TextView) findViewById(R.id.textView_nbrAbsence);

        DataLoadManager dataLoadManager = new DataLoadManager(
                AppConfig.URL_GET_NBPRESENCE,
                progressDialog,
                params,
                new DataLoadInterface() {
                    @Override
                    public void dataLoadReturn(Object object) {
                        if(object instanceof miage.upo.feuillepresence.models.Error){
                            Error error = (Error) object;
                            Toast.makeText(getApplicationContext(),
                                    error.getError(), Toast.LENGTH_LONG)
                                    .show();
                        }
                        if(object instanceof String){
                            nbrAbsence_textView.setText(object.toString());
                        }
                    }
                }
        );
        dataLoadManager.execute();

        Log.i("TAG_LOG", "EtudiantActivity - onBackClic message");
        /* Clic sur Back */
        Button back_button = (Button) findViewById(R.id.etudiant_activity_button_back);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        Button listAbsenceButton = (Button) findViewById(R.id.button_listAbsence);
        listAbsenceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = AbsenceActivity.newActivityIntent(EtudiantActivity.this);
                startActivity(intent);
            }
        });

    }

    public static void startActivity(Context context){
        Log.i("TAG_LOG","EtudiantActivity - startActivity message");
        Intent intent = new Intent(context, EtudiantActivity.class);
        context.startActivity(intent);
    }

    public static Intent newActivityIntent(Context context){
        Log.i("TAG_LOG", "EtudiantActivity - newActivityIntent message");
        Intent intent = new Intent(context, EtudiantActivity.class);
        return intent;
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG_LOG,"EtudiantActivity - onDestroy message");
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        Log.i(TAG_LOG, "EtudiantActivity - onStop message");
        super.onStop();
    }
}
