package miage.upo.feuillepresence.models;

/**
 * Created by BabyBryan on 21/04/2016.
 */
public class Error {
    public String error;

    public Error() {
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    @Override
    public String toString() {
        return "Error{" +
                "error='" + error + '\'' +
                '}';
    }
}
