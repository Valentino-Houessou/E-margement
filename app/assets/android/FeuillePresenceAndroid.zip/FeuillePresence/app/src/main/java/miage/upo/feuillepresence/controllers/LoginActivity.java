package miage.upo.feuillepresence.controllers;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.HashMap;

import miage.upo.feuillepresence.R;
import miage.upo.feuillepresence.app.AppConfig;
import miage.upo.feuillepresence.helpers.DataLoadInterface;
import miage.upo.feuillepresence.helpers.DataLoadManager;
import miage.upo.feuillepresence.helpers.SessionManager;
import miage.upo.feuillepresence.models.Error;
import miage.upo.feuillepresence.models.Utilisateur;

/**
 * Created by BabyBryan on 15/04/2016.
 */
public class LoginActivity extends Activity{

    private String TAG_LOG;
    private SessionManager session;
    private HashMap<String,String> params;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /* Creation Log */
        TAG_LOG = this.getClass().getCanonicalName();
        Log.i(TAG_LOG, "LoginActivity - onCreate message");

        /* Instanciation Activité */
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        /* Instanciation Button et EditText*/
        Button button_login = (Button) findViewById(R.id.login_activity_button_login);
        final EditText editText_email = (EditText) findViewById(R.id.login_activity_editText_email);
        final EditText editText_password = (EditText) findViewById(R.id.login_activity_editText_password);

        /* Instanciatioon d'un progressDialog pour Afficher un loader */
        /* Annulation impossible */
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        /* Instanciation de la Session */
        session = new SessionManager(getApplicationContext());

        /* Verification Login : Si oui on passe directement au MainActivity */
        if (session.isLoggedIn()) {
            MainActivity.startActivity(LoginActivity.this);
            finish();
        }

        /* Action sur le click */
        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /* Instanciation Hashmap parametre à envoyer */
                params = new HashMap<String, String>();
                /* Récupération des email et password */
                String email = editText_email.getText().toString();
                String password = editText_password.getText().toString();
                /* Vérification de données non null */
                if (!email.isEmpty() && !password.isEmpty()) {
                    /* Verification info en base */
                    /* Affectation message au dialog */
                    progressDialog.setMessage(getText(R.string.login_activity_progress_message));
                    /* Passage des parametres */
                    params.put("email",email);
                    params.put("password",password);
                    /* Lance AsyncTask */
                    DataLoadManager task = new DataLoadManager(AppConfig.URL_LOGIN, progressDialog, params, new DataLoadInterface() {
                        @Override
                        public void dataLoadReturn(Object object) {
                            if(object != null){
                                if(object instanceof Utilisateur){
                                    Utilisateur user = (Utilisateur) object;
                                    /* Creation de la session */
                                    session.createLoginSession(user.getId(),user.getNom(),user.getPrenom(),user.isEnseignant(),user.isEtudiant());
                                    /* Demarrage de l'Activité de redirection des Modules */
                                    Intent intent = MainActivity.newActivityIntent(getApplicationContext());
                                    startActivity(intent);
                                    finish();
                                }
                                if(object instanceof Error){
                                    Error error = (Error) object;
                                    Toast.makeText(getApplicationContext(),
                                            error.getError(), Toast.LENGTH_LONG)
                                            .show();
                                }
                            }else {
                                Toast.makeText(getApplicationContext(),
                                        R.string.global_toast_error, Toast.LENGTH_LONG)
                                        .show();
                            }
                        }
                    });
                    task.execute();
                } else {
                    /* Toast : demande de remplir les champs */
                    Toast.makeText(getApplicationContext(),
                            R.string.login_activity_toast_nologin, Toast.LENGTH_LONG)
                            .show();
                }
            }
        });
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG_LOG, "LoginActivity - onDestroy message");
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        Log.i(TAG_LOG, "LoginActivity - onStop message");
        super.onStop();
    }
}
