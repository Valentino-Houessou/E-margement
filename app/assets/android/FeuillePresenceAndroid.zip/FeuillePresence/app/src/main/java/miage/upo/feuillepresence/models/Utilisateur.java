package miage.upo.feuillepresence.models;

import java.sql.Timestamp;
import java.util.List;

public class Utilisateur{

    private long id;
    private String nom;
    private String prenom;
    private String adresseMail;
    private String motDePasse;
    private Timestamp dateDeNaissance;
    private String lienPhoto;
    private List<Module> sesModules;

    public Utilisateur() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getAdresseMail() {
        return adresseMail;
    }

    public void setAdresseMail(String adresseMail) {
        this.adresseMail = adresseMail;
    }

    public String getMotDePasse() {
        return motDePasse;
    }

    public void setMotDePasse(String motDePasse) {
        this.motDePasse = motDePasse;
    }

    public Timestamp getDateDeNaissance() {
        return dateDeNaissance;
    }

    public void setDateDeNaissance(Timestamp dateDeNaissance) {
        this.dateDeNaissance = dateDeNaissance;
    }

    public String getLienPhoto() {
        return lienPhoto;
    }

    public void setLienPhoto(String lienPhoto) {
        this.lienPhoto = lienPhoto;
    }

    public List<Module> getSesModules() {
        return sesModules;
    }

    public void setSesModules(List<Module> sesModules) {
        this.sesModules = sesModules;
    }

   public boolean isEnseignant(){
        if(sesModules.contains(new Module("ENSEIGNANTS")))
            return true;
       return false;
    }

    public boolean isEtudiant(){
        if(sesModules.contains(new Module("ETUDIANTS")))
            return true;
        return false;
    }

    @Override
    public String toString() {
        return "Utilisateur{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", prenom='" + prenom + '\'' +
                ", adresseMail='" + adresseMail + '\'' +
                ", motDePasse='" + motDePasse + '\'' +
                ", dateDeNaissance=" + dateDeNaissance +
                ", lienPhoto='" + lienPhoto + '\'' +
                ", sesModules=" + sesModules +
                '}';
    }


}
