package miage.upo.feuillepresence.models;

public class Etudiant{
    public long id;
    public String uid;
    public String numeroEtudiant;
    public String statut;
    public Utilisateur sonUtilisateur;

    public Etudiant() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getNumeroEtudiant() {
        return numeroEtudiant;
    }

    public void setNumeroEtudiant(String numeroEtudiant) {
        this.numeroEtudiant = numeroEtudiant;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Utilisateur getSonUtilisateur() {
        return sonUtilisateur;
    }

    public void setSonUtilisateur(Utilisateur sonUtilisateur) {
        this.sonUtilisateur = sonUtilisateur;
    }
}
