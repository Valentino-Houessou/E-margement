package miage.upo.feuillepresence.helpers;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import miage.upo.feuillepresence.R;
import miage.upo.feuillepresence.models.Cours;
import miage.upo.feuillepresence.models.Presence;

/**
 * Created by BabyBryan on 24/04/2016.
 */
public class ComplexeListAdapter extends ArrayAdapter<Object> {

    int layout_Id;
    String TAG_LOG;

    public ComplexeListAdapter(Context context, int resource, List<Object> objects) {
        super(context, resource, objects);
        /* Sauvegarde du layout */
        layout_Id = resource;
        /* Creation Log */
        TAG_LOG = this.getClass().getCanonicalName();
        Log.i(TAG_LOG, "ComplexeListAdapter - Constructor message");
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Log.i(TAG_LOG, "ComplexeListAdapter - getView message");
        /* Recupération du layout de la cellule */
        LayoutInflater inflater = (LayoutInflater) parent.getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row;
        if(null == convertView)
            row = inflater.inflate(layout_Id,parent,false);
        else
            row = convertView;
        switch (layout_Id){
            case R.layout.spinner_cours :
                    row = ForSpinnerCours(row,position);
                break;
            case R.layout.list_presence :
                row = ForListPresence(row,position);
                break;
            default:
                break;
        }
        return row;
    }

    private View ForListPresence(View view, int position) {
        Log.i(TAG_LOG, "ComplexeListAdapter - ForListPresence message");
        /* Recupération de la donnée */
        Object object = getItem(position);
        if(object instanceof Presence){
            Presence i = (Presence) object;
            /* Chargement des données */
            TextView student_id = (TextView) view.findViewById(R.id.presence_list_textView_id);
            TextView nom = (TextView) view.findViewById(R.id.presence_list_textView_nom);
            TextView prenom = (TextView) view.findViewById(R.id.presence_list_textView_prenom);
            ImageView absence = (ImageView) view.findViewById(R.id.presence_list_imageView_status);
            student_id.setText(i.getSonEtudiant().getNumeroEtudiant());
            nom.setText(i.getSonEtudiant().getSonUtilisateur().getNom());
            prenom.setText(i.getSonEtudiant().getSonUtilisateur().getPrenom());
            if(i.emergement)
                absence.setImageResource(R.color.presence_list_emargement_true);
            else
                absence.setImageResource(R.color.presence_list_emargement_false);
        }else{
            TextView nom = (TextView) view.findViewById(R.id.presence_list_textView_nom);
            nom.setText("Impossible de récupérer la liste !");
        }
        return view;
    }

    public View ForSpinnerCours(View view, int position){
        Log.i(TAG_LOG, "ComplexeListAdapter - ForSpinnerCours message");
        /* Recupération de la donnée */
        Object object = getItem(position);
        if(object instanceof Cours){
            Cours i = (Cours) object;
            /* Chargement des données */
            TextView id = (TextView) view.findViewById(R.id.cours_spinner_textView_id);
            TextView debut = (TextView) view.findViewById(R.id.cours_spinner_textView_debut);
            TextView libelle = (TextView) view.findViewById(R.id.cours_spinner_textView_libelle);
            TextView promotion = (TextView) view.findViewById(R.id.cours_spinner_textView_promotion);
            id.setText(String.valueOf(i.getId()));
            debut.setText(i.getHeureDebut().toString());
            libelle.setText(i.getSaMatiere().getLibelle().toString());
            promotion.setText(i.getSaPromo().getGroupe().toString() + " " + i.getSaPromo().getType().toString() + " " + i.getSaPromo().getFiliere().toString());
        }else if(object instanceof String){
            TextView debut = (TextView) view.findViewById(R.id.cours_spinner_textView_libelle);
            debut.setText(object.toString());
        } else{
            TextView debut = (TextView) view.findViewById(R.id.cours_spinner_textView_promotion);
            debut.setText("Impossible de récupérer la liste !");
        }
        /* Retourne la vue */
        return view;
    }
}
