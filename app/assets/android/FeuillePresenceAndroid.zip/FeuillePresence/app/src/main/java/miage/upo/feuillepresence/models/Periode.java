package miage.upo.feuillepresence.models;

import java.sql.Timestamp;

public class Periode{

    public int id;
    public String libelle;
    public Timestamp dateDeDeut;
    public Timestamp dateFin;

    public Periode() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public Timestamp getDateDeDeut() {
        return dateDeDeut;
    }

    public void setDateDeDeut(Timestamp dateDeDeut) {
        this.dateDeDeut = dateDeDeut;
    }

    public Timestamp getDateFin() {
        return dateFin;
    }

    public void setDateFin(Timestamp dateFin) {
        this.dateFin = dateFin;
    }
}
