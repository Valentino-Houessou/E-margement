package miage.upo.feuillepresence.helpers;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import java.util.HashMap;
import java.util.Map;

import miage.upo.feuillepresence.controllers.LoginActivity;

/**
 * Created by BabyBryan on 15/04/2016.
 */
public class SessionManager {
    /* Context */
    private Context _context;
    /* Shared Preference -> va contenir nos élement session */
    private SharedPreferences sharedPreferences;
    /* Editeur de SharedPreference */
    private SharedPreferences.Editor editor;
    /* Mode du SharedPreference */
    private int PRIVATE_MODE = 0;
    /* Fichier contenant le SharedPreference */
    private static final String PREF_NAME = "FeuillePresence";

    /* Element du SharedPreference */
    private static final String IS_LOGIN = "IsLoggedIn";
    private static final String KEY_NOM = "nom";
    private static final String KEY_PRENOM = "prenom";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_ENSEIGNANT = "enseignant";
    private static final String KEY_ETUDIANT = "etudiant";

    public SessionManager(Context _context) {
        this._context = _context;
        this.sharedPreferences = _context.getSharedPreferences(PREF_NAME,PRIVATE_MODE);
        this.editor = sharedPreferences.edit();
    }

    /**
     *  Crée une session quand on se log
     *  @param user_id  - L'id de l'utilisateur
     *  @param nom  - Le nom de l'utilisateur
     *  @param prenom  - Le prenom de l'utilisateur
     *  @param enseignant  - Si l'utilisateur est enseignant true : false
     *  @param etudiant  - Si l'utilisateur est etudiant true : false
     *
     *  */
    public void createLoginSession(long user_id, String nom, String prenom, boolean enseignant, boolean etudiant){
        /* Stockage de la valeur login a true*/
        editor.putBoolean(IS_LOGIN, true);
        /* Stokage des autres valeurs de l'utilisateur */
        editor.putString(KEY_NOM,nom);
        editor.putString(KEY_PRENOM,prenom);
        editor.putLong(KEY_USER_ID, user_id);
        editor.putBoolean(KEY_ETUDIANT, etudiant);
        editor.putBoolean(KEY_ENSEIGNANT, enseignant);
        /* Commit des changements */
        editor.commit();
    }

    /**
     *  Permet de récupérer les éléments la session
     *  */
    public Map<String,String> sessionData(){
        Map<String,String> map = new HashMap<String,String>();
        map.put(KEY_NOM,sharedPreferences.getString(KEY_NOM, "null"));
        map.put(KEY_PRENOM,sharedPreferences.getString(KEY_PRENOM, "null"));
        map.put(KEY_USER_ID,String.valueOf(sharedPreferences.getLong(KEY_USER_ID, -1)));
        map.put(KEY_ETUDIANT,String.valueOf(sharedPreferences.getBoolean(KEY_ETUDIANT, false)));
        map.put(KEY_ENSEIGNANT,String.valueOf(sharedPreferences.getBoolean(KEY_ENSEIGNANT, false)));
        return map;
    }

    /**
     *  Vérifie que l'utilisateur est logué : si non redirection vers LoginActivity
     *  */
    public void checkLogin(){
        if(!this.isLoggedIn()){
            /* Redirection Si user non logué */
            Intent intent = new Intent(_context,LoginActivity.class);
            /* Fermeture de toutes les activités qui peuvent etre ouverte */
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            /* Ajout d'un Flag pour démarrer une nouvelle activité */
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            /* Demarrage de LoginActivity */
            _context.startActivity(intent);
        }
    }

    public boolean isLoggedIn(){
        /* return true si on a une valeur avec la clé IS_LOGIN sinon false */
        return sharedPreferences.getBoolean(IS_LOGIN,false);
    }

    /**
     *  Suppression de la session
     *  */
    public void destroyLoginSession(){
        /* Suppression de toutes les données du SharedPreference */
        editor.clear();
        editor.commit();
         /* Redirection Si user non logué */
        Intent intent = new Intent(_context,LoginActivity.class);
            /* Fermeture de toutes les activités qui peuvent etre ouverte */
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
            /* Ajout d'un Flag pour démarrer une nouvelle activité */
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            /* Demarrage de LoginActivity */
        _context.startActivity(intent);
    }

    public void putInSession(String key, String value){
        /* Stokage des autres valeurs de l'utilisateur */
        editor.putString(key,value);
        /* Commit des changements */
        editor.commit();
    }
}
