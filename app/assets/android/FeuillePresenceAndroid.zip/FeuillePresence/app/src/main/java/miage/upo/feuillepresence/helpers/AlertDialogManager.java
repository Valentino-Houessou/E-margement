package miage.upo.feuillepresence.helpers;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

import miage.upo.feuillepresence.R;

/**
 * Created by BabyBryan on 15/04/2016.
 */
public class AlertDialogManager {

    /**
     *  Affiche un simple AlertDialog
     *  @param context  - Context de l'application
     *  @param title    - Titre du Dialog
     *  @param message  - Message du Dialog
     *  @param status   - succes/echec (à tuiliser pour mettre une icone)
     *                  - null si on ne veut rien mettre
     *  */
    public void showAlertDialog(Context context,String title, String message, Boolean status){
        /* Creation de alertdialog */
        AlertDialog alertDialog = new AlertDialog.Builder(context).create();
        /* Application du titre */
        alertDialog.setTitle(title);
        /* Application du message */
        alertDialog.setMessage(message);
        /* Application de l'icone */
        if(status != null)
            alertDialog.setIcon(status ? R.drawable.flag_green : R.drawable.flag_red);
        /* Application d'un bouton OK */
        alertDialog.setButton(DialogInterface.BUTTON_NEUTRAL,"OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        /* Affichage de l'alert */
        alertDialog.show();
    }
}
