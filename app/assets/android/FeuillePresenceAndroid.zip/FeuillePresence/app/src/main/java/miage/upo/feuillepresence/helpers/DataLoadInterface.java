package miage.upo.feuillepresence.helpers;

/**
 * Created by BabyBryan on 21/04/2016.
 */
public interface DataLoadInterface {
    public void dataLoadReturn(Object object);
}
