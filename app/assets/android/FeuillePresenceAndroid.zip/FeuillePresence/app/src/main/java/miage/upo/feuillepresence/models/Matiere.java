package miage.upo.feuillepresence.models;

public class Matiere{

    public int id;
    public String libelle;
    public String libelleAbregee;
    public String semestre;
    public long nombreHeures;

    public Matiere() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getLibelleAbregee() {
        return libelleAbregee;
    }

    public void setLibelleAbregee(String libelleAbregee) {
        this.libelleAbregee = libelleAbregee;
    }

    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        this.semestre = semestre;
    }

    public long getNombreHeures() {
        return nombreHeures;
    }

    public void setNombreHeures(long nombreHeures) {
        this.nombreHeures = nombreHeures;
    }
}
