package miage.upo.feuillepresence.controllers;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import miage.upo.feuillepresence.R;
import miage.upo.feuillepresence.helpers.SessionManager;

/**
 * Created by BabyBryan on 15/04/2016.
 */
public class MainActivity extends Activity {

    String TAG_LOG;
    SessionManager session;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /* Creation Log */
        TAG_LOG = this.getClass().getCanonicalName();
        Log.i(TAG_LOG, "MainActivity - onCreate message");
        /* Instanciation Activité */
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        /* Instanciation de la session --> session_start() php */
        session = new SessionManager(getApplicationContext());
        /* Verification de la connexion */
        session.checkLogin();
        /* Modification du textView Hello */
        TextView hello_textView = (TextView) findViewById(R.id.main_activity_textView_hello);
        hello_textView.setText(getText(R.string.main_activity_textView_hello) + " " +
                                session.sessionData().get("prenom") + " " +
                                session.sessionData().get("nom"));
        /* Modification de l'action sur le bouton */
        Button module_button = (Button) findViewById(R.id.main_activity_button_module);
        if(Boolean.valueOf(session.sessionData().get("etudiant"))) {
            module_button.setText(getText(R.string.main_activity_button_module) + " " +
                    getText(R.string.main_activity_etudiant));
            module_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    //TODO Redirection vers android Etudiant
                }
            });
        } else if(Boolean.valueOf(session.sessionData().get("enseignant"))){
            module_button.setText(getText(R.string.main_activity_button_module) + " " +
                    getText(R.string.main_activity_enseignant));
            module_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = EnseignantActivity.newActivityIntent(MainActivity.this);
                    startActivity(intent);
                }
            });
        }

        /* Clic sur Bouton Logout */
        Button logout_button = (Button) findViewById(R.id.main_activity_button_logout);
        logout_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                session.destroyLoginSession();
            }
        });
    }

    public static void startActivity(Context context){
        Log.i("TAG_LOG","MainActivity - startActivity message");
        Intent intent = new Intent(context, MainActivity.class);
        context.startActivity(intent);
    }

    public static Intent newActivityIntent(Context context){
        Log.i("TAG_LOG", "MainActivity - newActivityIntent message");
        Intent intent = new Intent(context, MainActivity.class);
        return intent;
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG_LOG,"MainActivity - onDestroy message");
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        Log.i(TAG_LOG, "MainActivity - onStop message");
        super.onStop();
    }

}
