package miage.upo.feuillepresence.models;

public class Salle{

    public int id;
    public String libelle;
    public Batiment sonBatiment;

    public Salle() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public Batiment getSonBatiment() {
        return sonBatiment;
    }

    public void setSonBatiment(Batiment sonBatiment) {
        this.sonBatiment = sonBatiment;
    }
}
