package miage.upo.feuillepresence.models;

public class Administrateur{

    private int id;
    private String statut;
    private Utilisateur sonUtilisateur;
    private boolean referentCFA;

    public Administrateur() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getStatut() {
        return statut;
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public Utilisateur getSonUtilisateur() {
        return sonUtilisateur;
    }

    public void setSonUtilisateur(Utilisateur sonUtilisateur) {
        this.sonUtilisateur = sonUtilisateur;
    }

    public boolean isReferentCFA() {
        return referentCFA;
    }

    public void setReferentCFA(boolean referentCFA) {
        this.referentCFA = referentCFA;
    }
}

