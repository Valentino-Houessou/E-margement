package miage.upo.feuillepresence.controllers;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import miage.upo.feuillepresence.R;
import miage.upo.feuillepresence.app.AppConfig;
import miage.upo.feuillepresence.helpers.AlertDialogManager;
import miage.upo.feuillepresence.helpers.ComplexeListAdapter;
import miage.upo.feuillepresence.helpers.DataLoadInterface;
import miage.upo.feuillepresence.helpers.DataLoadManager;
import miage.upo.feuillepresence.helpers.SessionManager;
import miage.upo.feuillepresence.models.Cours;
import miage.upo.feuillepresence.models.Error;

public class EnseignantActivity extends Activity {

    private String TAG_LOG;
    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /* Creation Log */
        TAG_LOG = this.getClass().getCanonicalName();
        Log.i(TAG_LOG, "EnseignantActivity - onCreate message");
        /* Instanciation Activité */
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enseignant);
        /* Cours à envoyer */
        final String[] extra_cours = {null,null};
        /* Instanciation de la session --> session_start() php */
        session = new SessionManager(getApplicationContext());
        /* Verification de la connexion */
        session.checkLogin();
        /* Creation datepicker */
        /* Récupere editText */
        final EditText datepicker_editText = (EditText) findViewById(R.id.enseignant_activity_editText_datepicker);
        /* Recupere date du jour */
        final Calendar c = Calendar.getInstance();
        final int year = c.get(Calendar.YEAR);
        final int month = c.get(Calendar.MONTH);
        final int day = c.get(Calendar.DAY_OF_MONTH);
        /* Creation du progressDialog */
        final ProgressDialog progressDialog = new ProgressDialog(EnseignantActivity.this);
        /* Creation du map send_item */
        final HashMap<String,String> send_item = new HashMap<>();
        onDatePickerClic(extra_cours, datepicker_editText, year, month, day, progressDialog, send_item);

        onBackClic();
        showPresence(extra_cours);
    }

    private void onDatePickerClic(final String[] extra_cours, final EditText datepicker_editText, final int year, final int month, final int day, final ProgressDialog progressDialog, final HashMap<String, String> send_item) {
        Log.i("TAG_LOG","EnseignantActivity - onDatePickerClic message");
        /* Sur clic on affiche le datepicker */
        datepicker_editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            DatePickerDialog dialog = new DatePickerDialog(EnseignantActivity.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                    /* Affichage de la date selectionner dans l'editText */
                    /* datepicker:month -> 0-11 */
                    datepicker_editText.setText(String.format("%02d", dayOfMonth) + "/"+ String.format("%02d", monthOfYear + 1) + "/" + year);
                    /* Configuration du progressDialog */
                    progressDialog.setMessage(getText(R.string.enseignant_activity_progress_message));
                    progressDialog.setCancelable(false);
                    /* Configuration du HashMap */
                    send_item.put("date",year + "-"+ String.format("%02d", monthOfYear + 1 ) + "-" + String.format("%02d", dayOfMonth) );
                    send_item.put("anId",session.sessionData().get("user_id"));
                    /* Trouver le spinner */
                    final Spinner spinner = (Spinner) findViewById(R.id.enseignant_activity_spinner_cours);
                    spinner.setAdapter(null);
                    extra_cours[0] = null;
                    /* Chargement de la liste des cours */
                    DataLoadManager dataLoadManager = new DataLoadManager(AppConfig.URL_GET_COURS_LIST, progressDialog, send_item, new DataLoadInterface() {
                        @Override
                        public void dataLoadReturn(Object object) {
                            if(object != null){
                                if(object instanceof List){
                                    initSpinner((List<Object>) object, spinner, extra_cours);
                                }
                                if(object instanceof Error){
                                    Error error = (Error) object;
                                    Toast.makeText(getApplicationContext(),
                                            error.getError(), Toast.LENGTH_LONG)
                                            .show();
                                }
                            }else {
                                Toast.makeText(getApplicationContext(),
                                        R.string.global_toast_error, Toast.LENGTH_LONG)
                                        .show();
                            }
                        }
                    });
                    dataLoadManager.execute();
                }
            }, year,month,day);
            dialog.setCanceledOnTouchOutside(true);
            dialog.show();
            }
        });
    }

    private void initSpinner(List<Object> object, Spinner spinner, final String[] extra_cours) {
        Log.i("TAG_LOG","EnseignantActivity - initSpinner message");
        /* Creation d'un Adapter utilisant la liste de Cours et un spinner par defaut */
        /* Element de la liste */
        List<Object> coursList = new ArrayList<Object>();
        coursList.add(getText(R.string.enseignant_activity_spinner_choice));
        for (int i = 0; i < object.size(); i++)
            coursList.add(object.get(i));
                                        /* Creation de l'adapter qui liera les données à la vue */
        ComplexeListAdapter complexeListAdapter = new ComplexeListAdapter(EnseignantActivity.this,R.layout.spinner_cours,coursList);
                                        /* Spécification du layout à utiliser quand la liste des choix apparait */
        complexeListAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                                        /* Association de l'adaptateur au layout */
        spinner.setAdapter(complexeListAdapter);
                                        /* Ajout dynamique de l'élément */
        complexeListAdapter.notifyDataSetChanged();
                                        /* Action sur le dataset Change */
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Object object =  parent.getItemAtPosition(position);
                if(object instanceof Cours){
                    Cours cours = (Cours) object;
                    extra_cours[0] = String.valueOf(cours.getId());
                    extra_cours[1] = getText(R.string.presence_activity_textView_title ) + " " + cours.getSaMatiere().libelleAbregee + "\n le " + cours.getHeureDebut();
                }else {
                    extra_cours[0] = null;
                    extra_cours[1] = null;
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void onBackClic() {
        Log.i("TAG_LOG","EnseignantActivity - onBackClic message");
        /* Clic sur Back */
        Button back_button = (Button) findViewById(R.id.enseignant_activity_button_back);
        back_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
    }

    private void showPresence(final String[] extra_cours) {
        Log.i("TAG_LOG","EnseignantActivity - showPresence message");
        /* Clic sur Voir liste */
        Button presence_button = (Button) findViewById(R.id.enseignant_activity_button_presence);
        presence_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(extra_cours[0] != null) {
                /* Creation des extras */
                    Intent intent = PresenceActivity.newActivityIntent(EnseignantActivity.this, extra_cours[0], extra_cours[1]);
                    startActivity(intent);
                }else{
                    Toast.makeText(getApplicationContext(),
                            R.string.enseignant_activity_toast_error, Toast.LENGTH_LONG)
                            .show();
                }
            }
        });
    }

    public static void startActivity(Context context){
        Log.i("TAG_LOG","EnseignantActivity - startActivity message");
        Intent intent = new Intent(context, EnseignantActivity.class);
        context.startActivity(intent);
    }

    public static Intent newActivityIntent(Context context){
        Log.i("TAG_LOG", "EnseignantActivity - newActivityIntent message");
        Intent intent = new Intent(context, EnseignantActivity.class);
        return intent;
    }

    @Override
    protected void onDestroy() {
        Log.i(TAG_LOG,"EnseignantActivity - onDestroy message");
        super.onDestroy();
    }

    @Override
    protected void onStop() {
        Log.i(TAG_LOG, "EnseignantActivity - onStop message");
        super.onStop();
    }

}
