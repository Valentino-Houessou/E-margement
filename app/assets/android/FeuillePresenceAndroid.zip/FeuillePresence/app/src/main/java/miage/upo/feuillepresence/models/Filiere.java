package miage.upo.feuillepresence.models;

public class Filiere{

    public int id;
    public String codefiliere;
    public String libelle;
    public String annee;
    public Batiment sonBatiment;


    public Filiere() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodefiliere() {
        return codefiliere;
    }

    public void setCodefiliere(String codefiliere) {
        this.codefiliere = codefiliere;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getAnnee() {
        return annee;
    }

    public void setAnnee(String annee) {
        this.annee = annee;
    }

    public Batiment getSonBatiment() {
        return sonBatiment;
    }

    public void setSonBatiment(Batiment sonBatiment) {
        this.sonBatiment = sonBatiment;
    }
}
