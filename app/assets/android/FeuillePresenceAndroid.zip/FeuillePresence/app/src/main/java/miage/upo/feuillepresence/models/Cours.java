package miage.upo.feuillepresence.models;

import java.sql.Timestamp;
import java.util.List;

public class Cours{

    public int id;
    public String type;
    public String type_detaille;
    public Timestamp heureDebut;
    public Timestamp heureFin;
    public Enseignant sonEnseignant;
    public Matiere saMatiere;
    public Salle saSalle;
    public Periode saPeriode;
    public Promotion saPromo;
    public List<Presence> sesPresences;
    public boolean signatureEnseignant;

    public Cours() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType_detaille() {
        return type_detaille;
    }

    public void setType_detaille(String type_detaille) {
        this.type_detaille = type_detaille;
    }

    public Timestamp getHeureDebut() {
        return heureDebut;
    }

    public void setHeureDebut(Timestamp heureDebut) {
        this.heureDebut = heureDebut;
    }

    public Timestamp getHeureFin() {
        return heureFin;
    }

    public void setHeureFin(Timestamp heureFin) {
        this.heureFin = heureFin;
    }

    public Enseignant getSonEnseignant() {
        return sonEnseignant;
    }

    public void setSonEnseignant(Enseignant sonEnseignant) {
        this.sonEnseignant = sonEnseignant;
    }

    public Matiere getSaMatiere() {
        return saMatiere;
    }

    public void setSaMatiere(Matiere saMatiere) {
        this.saMatiere = saMatiere;
    }

    public Salle getSaSalle() {
        return saSalle;
    }

    public void setSaSalle(Salle saSalle) {
        this.saSalle = saSalle;
    }

    public Periode getSaPeriode() {
        return saPeriode;
    }

    public void setSaPeriode(Periode saPeriode) {
        this.saPeriode = saPeriode;
    }

    public Promotion getSaPromo() {
        return saPromo;
    }

    public void setSaPromo(Promotion saPromo) {
        this.saPromo = saPromo;
    }

    public List<Presence> getSesPresences() {
        return sesPresences;
    }

    public void setSesPresences(List<Presence> sesPresences) {
        this.sesPresences = sesPresences;
    }

    public boolean isSignatureEnseignant() {
        return signatureEnseignant;
    }

    public void setSignatureEnseignant(boolean signatureEnseignant) {
        this.signatureEnseignant = signatureEnseignant;
    }

    @Override
    public String toString() {
        return "Cours du " + heureDebut;
    }
}
